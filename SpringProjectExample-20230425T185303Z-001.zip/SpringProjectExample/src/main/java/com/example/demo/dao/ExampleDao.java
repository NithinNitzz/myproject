package com.example.demo.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.dto.Example;
import com.example.demo.repository.ExampleRepository;

@Repository
public class ExampleDao {
	
	@Autowired
	public ExampleRepository exRepository;
	
	public Example insertExample(Example exam)
	{
		return exRepository.save(exam);
	}

	public Example searchById(int id)
	{
	    Optional<Example> opt=exRepository.findById(id);	
		
		if(opt.isPresent())
		{
		   return opt.get();	
		}
		return null;	
	}
	//to retrieve all objects from BD
		public List<Example> findAllEmployee()
		{
			return (List<Example>) exRepository.findAll();
		}
		//to delete an employee from DB
		public String deleteEmployee(int id)
		{
		 Example e=searchById(id);
		 if(e!=null)
		 {
			 exRepository.deleteById(id);
			 return "employee removed sucessfull ...";
		 }
		 return "Employee id not found....";
		}
}
