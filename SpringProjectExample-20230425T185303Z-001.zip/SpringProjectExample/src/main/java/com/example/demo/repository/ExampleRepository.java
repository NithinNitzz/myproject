package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.dto.Example;

public interface ExampleRepository extends CrudRepository<Example, Integer> {

}
