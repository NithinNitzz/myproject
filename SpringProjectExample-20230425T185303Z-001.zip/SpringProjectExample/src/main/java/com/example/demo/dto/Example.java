package com.example.demo.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Example {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String Title;
	private String Description;
	private int Duedate;
	private String Priorty;
	public Example(int id, String title, String description, int duedate, String priorty) {
		super();
		this.id = id;
		Title = title;
		Description = description;
		Duedate = duedate;
		Priorty = priorty;
	}
	public Example() {
		super();
		// TODO Auto-generated constructo
		r stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public int getDuedate() {
		return Duedate;
	}
	public void setDuedate(int duedate) {
		Duedate = duedate;
	}
	public String getPriorty() {
		return Priorty;
	}
	public void setPriorty(String priorty) {
		Priorty = priorty;
	}
	
	
}
