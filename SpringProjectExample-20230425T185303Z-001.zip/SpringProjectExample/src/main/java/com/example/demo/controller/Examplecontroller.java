package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.ExampleDao;
import com.example.demo.dto.Example;

@RestController
public class Examplecontroller {
	
	@Autowired
	public ExampleDao exampledao;
	
	@PostMapping("/exam")
	public Example addexample(@RequestBody Example exam)
	{
		return exampledao.insertExample(exam);
		
	}
	
	@GetMapping("/exam")
	
	public Example finByIdExample(int id)
	{
		return exampledao.searchById(id);
	}
	@GetMapping("/exam")
	public List<Example> findAllEmployee()
	{
		return exampledao.findAllEmployee();
	}
	@DeleteMapping("/exam")
	public String deleteEmployee(@RequestParam int id)
	{
		return exampledao.deleteEmployee(id);
	}
}
